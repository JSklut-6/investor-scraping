"""
Email Automation System for Investor Outreach
Uses Gmail API and Jinja2 templates for personalized campaigns
"""

import os
import base64
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from jinja2 import Template
from typing import List, Dict
import time
from datetime import datetime, timedelta


class EmailCampaign:
    """
    Automated email campaign manager for investor outreach
    """
    
    def __init__(self, template_name: str = "property_introduction"):
        self.template_name = template_name
        self.template = self._load_template(template_name)
        self.recipients = []
        self.gmail_service = None
        self._authenticate()
        
    def _authenticate(self):
        """Authenticate with Gmail API"""
        creds_path = os.getenv("GOOGLE_CREDENTIALS_PATH")
        
        if os.path.exists(creds_path):
            creds = Credentials.from_authorized_user_file(creds_path)
            self.gmail_service = build('gmail', 'v1', credentials=creds)
        else:
            print("Warning: Gmail credentials not found. Email sending will be simulated.")
    
    def _load_template(self, template_name: str) -> str:
        """Load email template from file"""
        template_path = f"email-automation/templates/{template_name}.html"
        
        if os.path.exists(template_path):
            with open(template_path, 'r') as f:
                return f.read()
        else:
            # Return default template
            return """
            <html>
            <body>
                <h2>New Investment Opportunity</h2>
                
                <p>Hi {{ investor_name }},</p>
                
                <p>I wanted to reach out about a property that matches your investment criteria:</p>
                
                <div style="background: #f5f5f5; padding: 20px; margin: 20px 0;">
                    <h3>{{ property_address }}</h3>
                    <ul>
                        <li><strong>Price:</strong> ${{ "{:,.0f}".format(purchase_price) }}</li>
                        <li><strong>ARV:</strong> ${{ "{:,.0f}".format(arv) }}</li>
                        <li><strong>Estimated Profit:</strong> ${{ "{:,.0f}".format(estimated_profit) }}</li>
                        <li><strong>ROI:</strong> {{ roi }}%</li>
                        <li><strong>Property Type:</strong> {{ property_type }}</li>
                    </ul>
                </div>
                
                <p><strong>Why this matches your profile:</strong></p>
                <p>{{ match_reason }}</p>
                
                <p>This property is in high demand. Are you interested in learning more?</p>
                
                <p>Best regards,<br>
                {{ agent_name }}<br>
                Prophet Homes<br>
                {{ agent_phone }}<br>
                {{ agent_email }}</p>
            </body>
            </html>
            """
    
    def add_recipients(self, investors: List[Dict]):
        """Add investors to campaign recipient list"""
        self.recipients.extend(investors)
    
    def customize_for_each_investor(self, property_data: Dict, agent_data: Dict):
        """Prepare customized emails for each investor"""
        self.customized_emails = []
        
        for investor in self.recipients:
            # Merge property data with investor-specific data
            email_data = {
                **property_data,
                **agent_data,
                'investor_name': investor.get('name', 'Investor'),
                'investor_email': investor.get('email'),
                'match_reason': self._generate_match_reason(investor, property_data),
                'estimated_profit': property_data.get('arv', 0) - property_data.get('purchase_price', 0) - property_data.get('rehab_cost', 0)
            }
            
            # Render template
            template = Template(self.template)
            html_content = template.render(**email_data)
            
            self.customized_emails.append({
                'to': investor.get('email'),
                'subject': f"Investment Opportunity: {property_data.get('property_address', 'New Property')}",
                'html': html_content,
                'investor_id': investor.get('investor_id'),
                'match_score': investor.get('match_score', 0)
            })
    
    def _generate_match_reason(self, investor: Dict, property: Dict) -> str:
        """Generate personalized match reasoning"""
        reasons = []
        
        if investor.get('budget_min', 0) <= property.get('purchase_price', 0) <= investor.get('budget_max', float('inf')):
            reasons.append("fits your budget range")
        
        if property.get('market') in investor.get('preferred_markets', []):
            reasons.append(f"located in your preferred {property.get('market')} market")
        
        if property.get('property_type') in investor.get('preferred_types', []):
            reasons.append(f"matches your preference for {property.get('property_type')} properties")
        
        roi = ((property.get('arv', 0) - property.get('purchase_price', 0) - property.get('rehab_cost', 0)) 
               / property.get('purchase_price', 1) * 100)
        
        if roi >= investor.get('target_roi', 0):
            reasons.append(f"offers {roi:.1f}% ROI (above your {investor.get('target_roi')}% target)")
        
        if reasons:
            return "This property " + ", ".join(reasons) + "."
        else:
            return "Based on your investment criteria, we believe this property could be a great fit."
    
    def send_email(self, email_data: Dict) -> bool:
        """Send a single email via Gmail API"""
        
        if not self.gmail_service:
            print(f"[SIMULATED] Email to {email_data['to']}: {email_data['subject']}")
            return True
        
        try:
            message = MIMEMultipart('alternative')
            message['to'] = email_data['to']
            message['subject'] = email_data['subject']
            
            html_part = MIMEText(email_data['html'], 'html')
            message.attach(html_part)
            
            raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode()
            
            send_message = self.gmail_service.users().messages().send(
                userId='me',
                body={'raw': raw_message}
            ).execute()
            
            print(f"✓ Email sent to {email_data['to']} (Match: {email_data.get('match_score', 0):.0f}%)")
            return True
            
        except Exception as e:
            print(f"✗ Failed to send to {email_data['to']}: {str(e)}")
            return False
    
    def execute(self, delay_seconds: int = 2) -> Dict:
        """
        Execute the email campaign
        
        Args:
            delay_seconds: Delay between emails to avoid rate limits
            
        Returns:
            Dict with campaign results
        """
        
        results = {
            'total': len(self.customized_emails),
            'sent': 0,
            'failed': 0,
            'errors': []
        }
        
        for email_data in self.customized_emails:
            success = self.send_email(email_data)
            
            if success:
                results['sent'] += 1
            else:
                results['failed'] += 1
                results['errors'].append({
                    'email': email_data['to'],
                    'investor_id': email_data['investor_id']
                })
            
            # Rate limiting
            time.sleep(delay_seconds)
        
        return results
    
    def schedule_followup(self, days: int = 3):
        """Schedule a follow-up campaign"""
        followup_date = datetime.now() + timedelta(days=days)
        
        print(f"Follow-up scheduled for {followup_date.strftime('%Y-%m-%d')}")
        
        # In production, this would integrate with Celery or n8n
        # For now, just log it
        return {
            'scheduled_date': followup_date.isoformat(),
            'recipients': len(self.recipients)
        }


# Example usage
if __name__ == "__main__":
    
    # Sample property data
    property_data = {
        'property_address': '123 Main St, Dallas, TX 75201',
        'purchase_price': 250000,
        'arv': 350000,
        'rehab_cost': 50000,
        'roi': 20,
        'property_type': 'Single Family',
        'market': 'Dallas'
    }
    
    # Agent data
    agent_data = {
        'agent_name': 'Jack Sklut',
        'agent_email': 'sklutjack@gmail.com',
        'agent_phone': '509-850-8369'
    }
    
    # Sample matched investors
    investors = [
        {
            'investor_id': 'INV001',
            'name': 'John Smith',
            'email': 'john@example.com',
            'match_score': 85,
            'budget_min': 200000,
            'budget_max': 300000,
            'preferred_markets': ['Dallas', 'Austin'],
            'preferred_types': ['Single Family'],
            'target_roi': 15
        },
        {
            'investor_id': 'INV002',
            'name': 'Jane Doe',
            'email': 'jane@example.com',
            'match_score': 78,
            'budget_min': 150000,
            'budget_max': 350000,
            'preferred_markets': ['Dallas'],
            'preferred_types': ['Single Family', 'Duplex'],
            'target_roi': 18
        }
    ]
    
    # Create and execute campaign
    campaign = EmailCampaign(template_name="property_introduction")
    campaign.add_recipients(investors)
    campaign.customize_for_each_investor(property_data, agent_data)
    
    print("Executing email campaign...")
    results = campaign.execute(delay_seconds=1)
    
    print(f"\nCampaign Results:")
    print(f"  Total: {results['total']}")
    print(f"  Sent: {results['sent']}")
    print(f"  Failed: {results['failed']}")
    
    # Schedule follow-up
    campaign.schedule_followup(days=3)
