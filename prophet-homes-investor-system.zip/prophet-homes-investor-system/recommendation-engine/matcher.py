"""
Investor-Property Recommendation Engine
Uses LightFM collaborative filtering to match investors to properties
"""

import numpy as np
import pandas as pd
from lightfm import LightFM
from lightfm.data import Dataset
from lightfm.evaluation import precision_at_k, auc_score
import pickle
import os
from typing import List, Dict, Tuple


class InvestorMatcher:
    """
    Recommendation system that matches investors to properties
    based on preferences, past behavior, and property characteristics
    """
    
    def __init__(self):
        self.model = None
        self.dataset = None
        self.user_id_map = {}  # investor_id -> internal_id
        self.item_id_map = {}  # property_id -> internal_id
        self.reverse_user_map = {}
        self.reverse_item_map = {}
        
    def prepare_training_data(
        self, 
        interactions_df: pd.DataFrame,
        investor_features_df: pd.DataFrame = None,
        property_features_df: pd.DataFrame = None
    ) -> Dataset:
        """
        Prepare data for training
        
        Args:
            interactions_df: DataFrame with columns [investor_id, property_id, interaction_type]
                interaction_type: 'viewed', 'contacted', 'made_offer', 'purchased' (weights: 1, 2, 3, 5)
            investor_features_df: Optional investor characteristics
            property_features_df: Optional property characteristics
        """
        
        # Build dataset
        dataset = Dataset()
        
        # Fit with unique investors and properties
        dataset.fit(
            users=interactions_df['investor_id'].unique(),
            items=interactions_df['property_id'].unique()
        )
        
        # Add features if provided
        if investor_features_df is not None:
            investor_features = self._build_investor_features(investor_features_df)
            dataset.fit_partial(user_features=investor_features)
            
        if property_features_df is not None:
            property_features = self._build_property_features(property_features_df)
            dataset.fit_partial(item_features=property_features)
        
        self.dataset = dataset
        
        # Create mappings
        self.user_id_map, self.reverse_user_map = dataset.mapping()[0]
        self.item_id_map, self.reverse_item_map = dataset.mapping()[2]
        
        return dataset
    
    def _build_investor_features(self, df: pd.DataFrame) -> List[str]:
        """Convert investor characteristics to feature tags"""
        features = []
        
        for _, investor in df.iterrows():
            features.append(f"experience:{investor.get('experience_level', 'unknown')}")
            features.append(f"risk:{investor.get('risk_tolerance', 'medium')}")
            features.append(f"strategy:{investor.get('strategy_preference', 'flip')}")
            features.append(f"budget:{investor.get('budget_tier', 'medium')}")
            
        return list(set(features))
    
    def _build_property_features(self, df: pd.DataFrame) -> List[str]:
        """Convert property characteristics to feature tags"""
        features = []
        
        for _, prop in df.iterrows():
            features.append(f"type:{prop.get('property_type', 'single_family')}")
            features.append(f"price_tier:{prop.get('price_tier', 'medium')}")
            features.append(f"market:{prop.get('market', 'dallas')}")
            features.append(f"condition:{prop.get('condition', 'average')}")
            
        return list(set(features))
    
    def train(
        self, 
        interactions_df: pd.DataFrame,
        epochs: int = 50,
        num_components: int = 30,
        learning_rate: float = 0.05
    ):
        """
        Train the recommendation model
        """
        
        # Convert interactions to weights
        interaction_weights = {
            'viewed': 1.0,
            'contacted': 2.0,
            'made_offer': 3.0,
            'purchased': 5.0
        }
        
        interactions_df['weight'] = interactions_df['interaction_type'].map(
            interaction_weights
        ).fillna(1.0)
        
        # Build interaction matrix
        (interactions, weights) = self.dataset.build_interactions(
            interactions_df[['investor_id', 'property_id', 'weight']].values
        )
        
        # Initialize model
        self.model = LightFM(
            no_components=num_components,
            learning_rate=learning_rate,
            loss='warp',  # WARP loss for implicit feedback
            random_state=42
        )
        
        # Train
        print(f"Training model for {epochs} epochs...")
        for epoch in range(epochs):
            self.model.fit_partial(
                interactions,
                sample_weight=weights,
                epochs=1
            )
            
            if (epoch + 1) % 10 == 0:
                train_precision = precision_at_k(
                    self.model, 
                    interactions, 
                    k=5
                ).mean()
                print(f"Epoch {epoch+1}: Precision@5 = {train_precision:.4f}")
    
    def find_best_investors(
        self, 
        property_id: str,
        top_n: int = 5,
        min_score: float = 0.0
    ) -> List[Dict]:
        """
        Find top N investors most likely to be interested in this property
        
        Args:
            property_id: The property to match
            top_n: Number of top matches to return
            min_score: Minimum match score (0-100)
            
        Returns:
            List of dicts with investor_id and match_score
        """
        
        if self.model is None:
            raise ValueError("Model not trained yet!")
        
        # Get internal property ID
        if property_id not in self.item_id_map:
            return []
        
        item_internal_id = self.item_id_map[property_id]
        
        # Get all investor internal IDs
        num_investors = len(self.user_id_map)
        investor_internal_ids = np.arange(num_investors)
        
        # Predict scores for all investors
        scores = self.model.predict(
            user_ids=investor_internal_ids,
            item_ids=np.array([item_internal_id] * num_investors)
        )
        
        # Convert to 0-100 scale (approximate)
        # Normalize scores
        min_raw_score = scores.min()
        max_raw_score = scores.max()
        if max_raw_score - min_raw_score > 0:
            normalized_scores = 100 * (scores - min_raw_score) / (max_raw_score - min_raw_score)
        else:
            normalized_scores = scores * 100
        
        # Get top N
        top_indices = np.argsort(scores)[::-1][:top_n]
        
        results = []
        for idx in top_indices:
            score = normalized_scores[idx]
            if score >= min_score:
                investor_id = self.reverse_user_map[idx]
                results.append({
                    'investor_id': investor_id,
                    'match_score': float(score),
                    'raw_score': float(scores[idx])
                })
        
        return results
    
    def find_best_properties(
        self,
        investor_id: str,
        property_ids: List[str],
        top_n: int = 5
    ) -> List[Dict]:
        """
        Find top N properties for a specific investor from a list of available properties
        """
        
        if self.model is None:
            raise ValueError("Model not trained yet!")
        
        if investor_id not in self.user_id_map:
            return []
        
        user_internal_id = self.user_id_map[investor_id]
        
        # Filter to properties we have mappings for
        valid_property_ids = [p for p in property_ids if p in self.item_id_map]
        item_internal_ids = [self.item_id_map[p] for p in valid_property_ids]
        
        if not item_internal_ids:
            return []
        
        # Predict scores
        scores = self.model.predict(
            user_ids=np.array([user_internal_id] * len(item_internal_ids)),
            item_ids=np.array(item_internal_ids)
        )
        
        # Sort and return top N
        top_indices = np.argsort(scores)[::-1][:top_n]
        
        results = []
        for idx in top_indices:
            property_id = valid_property_ids[idx]
            score = scores[idx]
            results.append({
                'property_id': property_id,
                'match_score': float(score * 20),  # Scale to 0-100
                'raw_score': float(score)
            })
        
        return results
    
    def save_model(self, filepath: str):
        """Save trained model to disk"""
        model_data = {
            'model': self.model,
            'dataset': self.dataset,
            'user_id_map': self.user_id_map,
            'item_id_map': self.item_id_map,
            'reverse_user_map': self.reverse_user_map,
            'reverse_item_map': self.reverse_item_map
        }
        
        with open(filepath, 'wb') as f:
            pickle.dump(model_data, f)
        
        print(f"Model saved to {filepath}")
    
    def load_model(self, filepath: str):
        """Load trained model from disk"""
        with open(filepath, 'rb') as f:
            model_data = pickle.load(f)
        
        self.model = model_data['model']
        self.dataset = model_data['dataset']
        self.user_id_map = model_data['user_id_map']
        self.item_id_map = model_data['item_id_map']
        self.reverse_user_map = model_data['reverse_user_map']
        self.reverse_item_map = model_data['reverse_item_map']
        
        print(f"Model loaded from {filepath}")


# Example usage
if __name__ == "__main__":
    
    # Sample training data
    interactions = pd.DataFrame({
        'investor_id': ['INV001', 'INV001', 'INV002', 'INV002', 'INV003', 'INV003'],
        'property_id': ['PROP001', 'PROP002', 'PROP002', 'PROP003', 'PROP001', 'PROP004'],
        'interaction_type': ['viewed', 'purchased', 'contacted', 'viewed', 'made_offer', 'purchased']
    })
    
    # Initialize and train
    matcher = InvestorMatcher()
    matcher.prepare_training_data(interactions)
    matcher.train(interactions, epochs=30)
    
    # Find best investors for a property
    print("\nTop investors for PROP001:")
    matches = matcher.find_best_investors('PROP001', top_n=3)
    for match in matches:
        print(f"  {match['investor_id']}: {match['match_score']:.1f}% match")
    
    # Save model
    matcher.save_model('models/investor_matcher.pkl')
